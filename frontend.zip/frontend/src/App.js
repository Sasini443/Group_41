import './App.css';
import Header from './components/header';
import addStudent from './components/addStudent';
import AllStudents from './components/AllStudents';
import {BrowserRouter as Router, Route} from "react-router-dom"
//import React, { Component } from 'react';


function App() {
  return (
    <Router>
      <div>
      
     <Header/>
      
        <Route path="/add" exact component={addStudent}/>
        <Route path="/" exact component={AllStudents}/>
      
    </div>
    </Router>
  );
}

export default App;
