import React, {useState, useEffect} from "react";
import axios from "axios";

export default function AllStudents(){
    const [students, setStudents] = useState([]);
    useEffect(()=>{
       function getStudent(){
        axios.get("http://localhost:8070/student/").then((res)=>{
            
            setStudents(res.data);
        }).catch((err)=>{
            alert(err.message);
        })
       }
       getStudent();
        
    }, [])
    return(
        <div className="Container">
            <h1>All Students</h1>

        </div>
    )

}
